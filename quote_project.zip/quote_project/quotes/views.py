from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Quote
import random
import json

def generate_quote():
    response = requests.get("https://zenquotes.io/api/random")
    if response.status_code == 200:
        data = response.json()
        quote = data[0]['q']
        author = data[0]['a']

        return {'quote':quote ,'author': author}

    else:
        return 'Failed to fetch a quote'


def get_random_quote(request):
    quotes =  generate_quote()
    if quotes:
        data = {"quote": quote.get('quote'), "author": quote.get('author')}
    else:
        data = {"quote": "", "author": ""}
    return JsonResponse(data)

csrf_exempt
def add_quote(request):
    if request.method == "GET":
        try:
            data = json.loads(request.body)
            quote_text = data.get("quote")
            author_text = data.get("author")
            if quote_text and author_text:
                quote = Quote(quote=quote_text, author=author_text)
                quote.save()
                return JsonResponse({"id": quote.id})
            else:
                return JsonResponse({"error": "Missing quote or author"}, status=400)
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON"}, status=400)
    return JsonResponse({"error": "Method not allowed"}, status=405)
