from django.urls import path
from .views import get_random_quote, add_quote

urlpatterns = [
    path('random/', get_random_quote, name='random_quote'),
    path('add/', add_quote, name='add_quote'),
]
